# Changelog

Changelog of ASAM ODS CORBA API Java library by Peak Solution GmbH.

## [5.3.1.2] - 2025-06-12
### Changed
- adjusted pom.xml and Maven deploy workflow, replaced build artifacts

---

## [5.3.1.1] - 2025-06-11
### Added
- first official release

---

## [Template]
### Added

### Changed

### Fixed

### Deprecated/Removed

---
