# Changelog

Changelog of ASAM ODS CORBA API Java library by Peak Solution GmbH.

## [Template]
### Added

### Changed

### Fixed

### Deprecated/Removed

---

## [5.3.1.1] - 2025-06-11
### Added
- first official release 