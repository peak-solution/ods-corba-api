# Changelog

Changelog of ASAM ODS CORBA API Java library by Peak Solution GmbH.

---

## [5.3.1.3] - 2025-06-13
### Changed
- adjusted pom.xml and Maven deploy workflow, replaced build artifacts

### Fixed
- The Maven central artifact was an empty jar file. This has been fixed by adjusting the build process (local build including gpg signing) and GitHub Action for releasing to Maven central.

---

## [5.3.1.2] - 2025-06-12
### Changed
- adjusted pom.xml and Maven deploy workflow, replaced build artifacts

---

## [5.3.1.1] - 2025-06-11
### Added
- first official release

---

## [Template]
### Added

### Changed

### Fixed

### Deprecated/Removed

---
